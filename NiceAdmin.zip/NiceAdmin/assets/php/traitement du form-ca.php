<?php
$servername = "localhost";
$username = "root";
$password = "root";
$database = "form";

try {
    // Connexion au serveur MySQL
    $connexion = new PDO("mysql:host=$servername;dbname=$database", $username, $password);
    $connexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    //echo "Connexion établie<br>";
    //echo "Saisissez vos informations<br>";
} catch (PDOException $e) {
    echo "La connexion a échoué : " . $e->getMessage();
}

if(isset($_POST['Enregistrer'])) {
    //echo "Saisissez vos informations<br>";
    $Expediteur = $_POST['Expediteur'];
    $Objet = $_POST['Objet'];
    $Ncorresp = $_POST['Ncorresp'];
    $Date = $_POST['Date'];
    $Description = $_POST['Description'];

    echo $Objet;
    echo $Date;
    echo $Expediteur;

    try {
        // Requête d'insertion préparée
        $sql = "INSERT INTO `form`(`Correspondance`, `expediteur`, `Date`, `Objet`, `description`) VALUES (':Ncorresp',':Expediteur',':Date',':Objet',':Description')";
        $stmt = $connexion->prepare($sql);
        $stmt->bindParam(':Date', $Date);
        $stmt->bindParam(':Ncorresp', $Ncorresp);
        $stmt->bindParam(':Expediteur', $Expediteur);
        $stmt->bindParam(':Objet', $Objet);
        $stmt->bindParam(':Description', $Description);
        echo " . Exécution<br>";
        $stmt->execute();
        echo "Données insérées";
    } catch (PDOException $e) {
        echo "Erreur lors de l'insertion des données : ". $e->getMessage();
    }
}
?>
