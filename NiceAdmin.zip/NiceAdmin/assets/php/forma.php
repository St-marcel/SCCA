<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "root";
$database = "register";

echo ('connexion');
try {
    // Connexion au serveur MySQL
    $connexion = new PDO("mysql:host=$servername;dbname=$database", $username, $password);
    $connexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    //echo "Connexion établie<br>";
    //echo "Saisissez vos informations<br>";
} catch (PDOException $e) {
    echo "La connexion a échoué : " . $e->getMessage();
}
echo ('teste');

if(isset($_POST['Enregistrer'])) {
    if(!empty($_POST['Nom']) AND !empty($_POST['Mdp'])){
    $Nom = htmlspecialchars($_POST['Nom']);
    $Role = $_POST['Role'];
    $Direction = $_POST['Direction'];
    $Mdp = sha1($_POST['Mdp']);
  echo "demare";
    try {
        echo "friiiizzz";
        // Requête d'insertion préparée
        $sql = $connexion->prepare('INSERT INTO forma(id_form, NOM, ROLE, DIRECTION, MDP) VALUES (null,?,?,?,?)');
        $sql->execute(array($Nom, $Role ,$Direction,$Mdp));
        $recupUser = $connexion->prepare('SELECT * FROM forma WHERE NOM = ? AND MDP = ? ');
        $recupUser->execute(array($Nom ,$Mdp));
        echo "fefefe";
        if($recupUser->rowCount() > 0){
            $_SESSION['Nom'] = $Nom;
            $_SESSION['Mdp'] = $Mdp;
            $_SESSION['Direction'] = $Direction;
            $_SESSION['Role'] = $Role;
            $_SESSION['id_form'] = $recupUser-> fetch()['id_form'];
            header('Location: ../../pages-login.html');
        }
    echo "fefefe";
        echo $_SESSION['id_form'];

    } catch (PDOException $e) {
        echo "Erreur lors de l'insertion des données : ". $e->getMessage();
    }
    }else{
        echo "Completez les champs vides...";
    }
    //echo "Saisissez vos informations<br>";
    
   
}

?>
