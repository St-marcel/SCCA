<?php
    session_start();
    $servername = "localhost";
    $username = "root";
    $password = "root";
    $database = "register";

    try {
        // Connexion au serveur MySQL
        $connexion = new PDO("mysql:host=$servername;dbname=$database", $username, $password);
        $connexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        //echo "Connexion établie<br>";
        //echo "Saisissez vos informations<br>";
    } catch (PDOException $e) {
        echo "La connexion a échoué : " . $e->getMessage();
    }

    if(isset($_POST['Connexion'])){
        if(!empty($_POST['Nom']) AND  !empty($_POST['Mdp'])){
            $Nom = htmlspecialchars($_POST['Nom']);
            $Mdp = sha1($_POST['Mdp']);

            $recupUser = $connexion->prepare('SELECT*FROM forma WHERE NOM = ? AND MDP = ?');
            $recupUser->execute(array($Nom, $Mdp));

            if($recupUser->rowCount()>0){
                $_SESSION['Nom'] = $Nom;
                $_SESSION['Mdp'] = $Mdp;
                $_SESSION['Role']= $recupUser->fetch()['ROLE'];
                $_SESSION['id'] = $recupUser->fetch()['id_form'];
                header('Location: ../../index.php');

            }else{
                header('Location:../../pages-login.html');
            }
        }else{
             echo "Veillez remplir les champs vides...";

        }
    }
    exit
?>